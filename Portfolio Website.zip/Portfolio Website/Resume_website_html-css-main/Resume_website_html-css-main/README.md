# Resume_website_html-css
This is the resume project using HTML  and CSS
